﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Datos1;
using Datos1.Acessos;
using Datos1.Atributos;

namespace _3_EjercicioElsy
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Aceptarbutton1_Click(object sender, EventArgs e)
        {
            UsuarioA1 usuarioA1 = new UsuarioA1();
            Usuario usuario = new Usuario();
            usuario = usuarioA1.Login(UsuariotextBox1.Text, ContratextBox2.Text);
            Registros registros = new Registros();
            registros.Show();
            this.Hide();
        }

        private void Cancelarbutton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
