﻿using Datos1.Acessos;
using Datos1.Atributos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3_EjercicioElsy
{
    public partial class Registros : Form
    {
        public Registros()
        {
            InitializeComponent();
        }
        UsuarioA1 usuarioA1 = new UsuarioA1();
        private void Registros_Load(object sender, EventArgs e)
        {
            registroUsuarios();
        }

        private void registroUsuarios()
        {
            RegistrdataGridView1.DataSource = usuarioA1.registroUsuarios();


        }

        
    }
}
