﻿using Datos1.Atributos;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos1.Acessos
{
    public class UsuarioA1
    {
        readonly string Cadena = "Server = localhost; Port = 3306; Database = ejercicio; Vid = root ; Pwd = 123456;";

        MySqlConnection conn;
        MySqlCommand cmd;
        public Usuario Login(String codigo, string contraseña)
        {
            Usuario user = null;

            try
            {
                string sql = "SELECT * FROM registro WHERE Codigo = @Codigo AND Contraseña = @Contraseña;";

                conn = new MySqlConnection(Cadena);
                conn.Open();

                cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Codigo", codigo);
                cmd.Parameters.AddWithValue("@Contraseña", contraseña);

                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    user = new Usuario();
                    user.Codigo = reader[0].ToString();
                    user.Nombre = reader[1].ToString();
                    user.Contraseña = reader[2].ToString();
                }
                reader.Close();
                conn.Close();
            }
            catch (Exception ex)
            {

            }
            return user;
        }
        public DataTable registroUsuarios()
        {
            DataTable registroUsuariosDT = new DataTable();
            try
            {
                string sql = "SELECT * FROM registro;";
                conn = new MySqlConnection(Cadena);
                conn.Open();

                cmd = new MySqlCommand(sql, conn);

                MySqlDataReader reader = cmd.ExecuteReader();
                registroUsuariosDT.Load(reader);
                reader.Close();
                conn.Close();
            }
            catch (Exception ex)
            {

            }
            return registroUsuariosDT;
        }


    }
}







